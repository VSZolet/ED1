#include<stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

typedef struct dadosS /** Struct da lista sequencial. */
{
    int rg;
    char nome[20];
}CadastroS;

typedef struct dadosE /** Struct da lista encadeada. */
{
    int rg;
    struct dados *proximo, *anterior;
    char nome[20];
}CadastroE;

/** Opcoes da lista sequencial. */

int AdicionaPrimeiro(long unsigned int j, CadastroS *lista)
{
    long unsigned int c=0, m=0;
    clock_t inicio, fim;

    inicio = clock();
    c++;
    if (j==0)
    {
        fim=clock();
        printf("\nInsira o Primeiro Nome: ");
        scanf("%s", &lista[0].nome);
        printf("\nInsira o RG: ");
        scanf("%d", &lista[0].rg);

    }
    else
    {

        while(j>0)
        {
            strcpy(lista[j+1].nome,lista[j].nome);
            lista[j+1].rg=lista[j].rg;
            m+=2;
            c++;
            j--;
        }
        strcpy(lista[j+1].nome,lista[j].nome);
        lista[j+1].rg=lista[j].rg;
        m+=2;
        fim=clock();

        printf("\nInsira o Primeiro Nome: ");
        scanf("%s", &lista[0].nome);
        printf("\nInsira o RG: ");
        scanf("%d", &lista[0].rg);

    }

    printf("\nFoi inserido na primeira posicao. C=%d e M=%d. Tempo de Execucao: %.2fs.\n", c, m, (double)(fim-inicio)/CLOCKS_PER_SEC);

    return 1;
}

int AdicionaUltimo(long unsigned int j, CadastroS *lista)
{
    clock_t inicio, fim;

    printf("\nInsira o Primeiro Nome: ");
    scanf("%s", &lista[j].nome);
    printf("\nInsira o RG: ");
    scanf("%d", &lista[j].rg);

    inicio=clock();
    fim=clock();

    printf("\nAdicionado na ultima posicao, %d. C=1 e M=1. Tempo de Execucao: %.2fs.\n",j+1, (double)(fim-inicio)/CLOCKS_PER_SEC);

    return 1;

}

int AdicionaPosicao(long unsigned int j, CadastroS *lista)
{
    long unsigned int aux, m=0, c=0;
    clock_t inicio, fim;

    printf("\nInsira posicao que deseja inserir: ");
    scanf("%d", &aux);

    while(aux-1>j)
    {
        c++;
        printf("\nPosicao maior que %d, o seguinte do ultimo da fila.\n", j+1);
        printf("\nInsira posicao que deseja inserir: ");
        scanf("%d", &aux);
    }

    inicio=clock();

    while(j>aux-1)
    {
        strcpy(lista[j+1].nome,lista[j].nome);
        lista[j+1].rg=lista[j].rg;
        m+=2;
        c++;
        j--;
    }
    strcpy(lista[j+1].nome,lista[j].nome);
    lista[j+1].rg=lista[j].rg;

    fim=clock();

    printf("\nInsira o Primeiro Nome: ");
    scanf("%s", &lista[j].nome);
    printf("\nInsira o RG: ");
    scanf("%d", &lista[j].rg);

    printf("\nFoi inserido na posicao %d. C=%d e M=%d. Tempo de Execucao: %.2fs.\n", aux, c, m, (double)(fim-inicio)/CLOCKS_PER_SEC);

    return 1;

}

int RetiraPrimeiro(long unsigned int j, CadastroS *lista)
{
    long unsigned int i=j, m=0, c=0;
    clock_t inicio, fim;

    inicio=clock();

    c++;
    if(j==0)
    {
        fim=clock();
        printf("\nA lista está vazia, impossível retirar.");
        return 0;
    }
    else
    {
        j=0;
        while(j<i)
        {
            strcpy(lista[j].nome,lista[j+1].nome);
            lista[j].rg=lista[j+1].rg;
            m+=2;
            c++;
            j++;
        }
        strcpy(lista[j].nome,"");
        lista[j].rg=0;
    }

    fim=clock();

    printf("\nFoi retirado da primeira posicao. C=%d e M=%d. Tempo de Execucao: %.2fs.\n", c, m, (double)(fim-inicio)/CLOCKS_PER_SEC);

    return 1;

}

int RetiraUltimo(long unsigned int j, CadastroS *lista)
{
    long unsigned int c=0, m=0;
    clock_t  inicio, fim;

    inicio=clock();

    c++;
    if(j==0)
    {
        fim=clock();
        printf("\nA lista está vazia, impossível retirar.");
        return 0;
    }
    else
    {
        strcpy(lista[j-1].nome,"");
        lista[j-1].rg=0;
        m++;
    }
    fim=clock();

    printf("\nFoi retirado da ultima posicao, %d. C=%d e M=%d. Tempo de Execucao: %.2fs.\n", j, c, m, (double)(fim-inicio)/CLOCKS_PER_SEC);

    return 1;
}

int RetiraPosicao(long unsigned int k, CadastroS *lista)
{
    long unsigned int aux, j, m=0, c=0;
    clock_t inicio, fim;

    printf("\nInsira posicao que deseja retirar: ");
    scanf("%d", &j);

    while(j-1>k)
    {
        c++;
        printf("\nPosicao maior que %d, o seguinte do ultimo da fila.\n", j+1);
        printf("\nInsira posicao que deseja inserir: ");
        scanf("%d", &j);
    }

    inicio=clock();
    aux=j;
    j--;

    while(j-1<k)
    {
        strcpy(lista[j].nome,lista[j+1].nome);
        lista[j].rg=lista[j+1].rg;
        m+=2;
        c++;
        j++;
    }
    strcpy(lista[j].nome,"");
    lista[j].rg=0;

    fim=clock();

    printf("\nFoi retirado da posicao %d. C=%d e M=%d. Tempo de Execucao: %.2fs.\n", aux, c, m, (double)(fim-inicio)/CLOCKS_PER_SEC);

    return 1;
}

int ProcuraRG(long unsigned int k, CadastroS *lista)
{
    int rg, j, aux=0;
    long unsigned int c=0, m=0;
    clock_t inicio, fim;

    printf("\nInsira RG para busca: ");
    scanf("%d", &rg);

    inicio=clock();

    for(j=0; j<k; j++)
    {
        c+=2;
        if(rg==lista[j].rg)
        {
            aux=1;
            printf("\nEncontrado na posicao %d. Nome: %s, RG: %d.\n", j+1, lista[j].nome, lista[j].rg);
            break;
        }
    }

    c++;
    if(aux==1)
    {
        fim=clock();
        printf("\nC=%d e M=%d. Tempo de Execucao: %.2fs.\n", c, m, (double)(fim-inicio)/CLOCKS_PER_SEC);
    }
    else
    {
        fim=clock();
        printf("\nNao encontrado na lista. C=%d e M=%d. Tempo de Execucao: %.2fs.\n", c, m, (double)(fim-inicio)/CLOCKS_PER_SEC);
    }

    return 0;

}

int OrdenaLista(long unsigned int j, CadastroS *lista)
{
    int opcao;

    do
    {
        printf("Escolha entre 1 a 6 para a forma de ordenacao: ");
        scanf("%d",  &opcao);
        if(opcao==1)
            SelectionSort(j, lista);
        else if (opcao==2)
        {}
        else if (opcao==3)
        {}
        else if (opcao==4)
        {}
        else if (opcao==5)
        {}
        else if (opcao==6)
        {}
        else
            printf("\nOpcao Invalida\n");
    }while (opcao<1 || opcao>6);
}

int VerLista(long unsigned int k, CadastroS *lista)
{
    long unsigned int j, c=0;
    clock_t inicio, fim;
    printf("\n");

    inicio=clock();

    c++;
    if(k==0)
    {
        printf("A lista esta vazia.\n");
    }
    for(j=0;j<k;j++)
    {
        c++;
        printf("Linha %d: %s, %d\n", j+1, lista[j].nome, lista[j].rg);
    }

    fim=clock();

    printf("\nC=%d, M=0. Tempo de Execucao: %.2fs.\n", c, (double)(fim-inicio)/CLOCKS_PER_SEC);

    return 0;

}

int SalvaLista(long unsigned int k, CadastroS *lista)
{
    long unsigned int j, c=0;
    clock_t inicio, fim;
    char url[31];
    FILE *arq;

    inicio=clock();

	printf("\nEscolha um nome para o arquivo ate 30 caracteres, contando com a extensao do mesmo: ");
	scanf("%s", &url);

	inicio=clock();
	arq = fopen(url, "w");
	c++;
	if(arq == NULL)
    {
        fim=clock();
        printf("Erro, nao foi possivel salvar o arquivo.\n");
        return 0;
    }
	else
    {
        for(j=0; j<k; j++)
        {
            c++;
            fprintf(arq, "%s,%d", lista[j].nome, lista[j].rg);
        }
    }
    fclose(arq);

    fim=clock();

    printf("\nArquivo %s criado com exito. C=%d e M=0. Tempo de Execucao: %.2f\n", url, c, (double)(fim-inicio)/CLOCKS_PER_SEC);

    return 0;
}

int LerLista(long unsigned int j, CadastroS *lista)
{
    char  url[20], nome[20];
    int   rg, c=0, m=0, k=j;
    clock_t inicio, fim;
    FILE *arq;

    fflush(stdin);
    printf("\nDigite o nome do arquivo: ");
    scanf("%s", url);

    inicio=clock();
    arq = fopen(url, "r");
    c++;
    if(arq == NULL)
    {
        fim=clock();
        printf("\nErro, nao foi possivel abrir o arquivo.\n");
        return 0;
    }
    else
    {
        c++;
        while( (fscanf(arq,"%[^,],%d\n", &nome, &rg))!=EOF )
        {
            c++;
            strcpy(lista[j].nome,nome);
            lista[j].rg=rg;
            m+=2;
            j++;
        }
    }
    fclose(arq);

    fim=clock();

    printf("\nLista adicionada entre posicao %d e %d. C=%d e M=%d. Tempo de Execucao: %.2fs.\n", k+1, j, c, m, (double)(fim-inicio)/CLOCKS_PER_SEC);

    return j-k;
}

/** Fim das opcoes sequencias */

/** Opcoes de ordenacao sequencial */

int SelectionSort(long unsigned int k, CadastroS *lista)
{
    CadastroS aux;
    int aux2, aux3;
    long unsigned int i, j;

    for(j=0; j<k; j++){

        aux2=lista[j].rg;

        for(i=j; i<10; i++)
        {
            if(lista[i].rg<=aux2)
            {
                aux=lista[i];
                aux3=i;
            }
        }
        lista[aux3]=lista[j];
        lista[j]=aux;
    }
}
int InsertionSort()
{}
int BubbleSort()
{}
int ShellSort()
{}
int QuickSort()
{}
int MergeSort()
{}

int main()
{
    int opcaoF;

    do{
    printf("Escolha 1 para Sequencial, 2 para Encadeado: ");
    scanf("%d", &opcaoF);
    printf("\n");
    }while(opcaoF<1 || opcaoF>2);

    if (opcaoF==1) /** Leva para Opcoes de uma lista encadeada, iniciando variaveis necessarias. */
    {
        int opcao;
        long unsigned int i=23496886, j=0;
        CadastroS *lista;
        lista=malloc(i*sizeof(CadastroS));

        do /*** Opcoes do programa ***/
        {
            printf("Selecione Uma Opcao de 1 a 12: ");
            scanf("%d", &opcao);

            if(opcao==1)
                j+=AdicionaPrimeiro(j, lista);
            else if(opcao==2)
                j+=AdicionaUltimo(j, lista);
            else if(opcao==3)
                j+=AdicionaPosicao(j, lista);
            else if(opcao==4)
                j-=RetiraPrimeiro(j, lista);
            else if(opcao==5)
                j-=RetiraUltimo(j, lista);
            else if(opcao==6)
                j-=RetiraPosicao(j, lista);
            else if(opcao==7)
                ProcuraRG(j, lista);
            else if(opcao==8)
                OrdenaLista(j, lista);
            else if(opcao==9)
                VerLista(j, lista);
            else if(opcao==10)
                SalvaLista(j, lista);
            else if(opcao==11)
                j+=LerLista(j, lista);
            else if(opcao<1 || opcao>12)
                printf("\nOpcao Invalida.\n");

        }while(opcao!=12);

        return 1;
    }
    else
    {
        char url[31], nome[20];
        unsigned long int i=0;
        int opcao, rg;
        CadastroE *novoNo, *primeiro, *ultimo, *atual;
        long unsigned int c, m;
        clock_t inicio, fim;
        FILE *arq;

        primeiro=(CadastroE *)malloc(1*sizeof(CadastroE));
        primeiro=NULL;
        ultimo=(CadastroE *)malloc(1*sizeof(CadastroE));

        do{
            printf("Selecione uma opcao de 1 a 11: ");
            scanf("%d", &opcao);
            if(opcao==1)       /** Insere Primeiro */
            {

                c=0, m=0;

                printf("\nInsira o Nome: ");
                scanf("%s", nome);
                printf("\nInsira o RG: ");
                scanf("%d", &rg);

                inicio=clock();

                novoNo=(CadastroE *)malloc(1*sizeof(CadastroE));
                strcpy(novoNo->nome,nome);
                novoNo->rg=rg;
                novoNo->proximo=NULL;
                m+=3;

                c++;
                if(primeiro!=NULL)
                {
                    novoNo->proximo=primeiro;
                    primeiro->anterior=novoNo;
                    m+=2;
                }
                else
                {
                    ultimo=novoNo;
                    m++;
                }
                primeiro=novoNo;
                primeiro->anterior=NULL;

                m+=2;
                i++;
                fim=clock();

                printf("\nFoi inserido na primeira posicao. C=%d e M=%d. Tempo de Execucao: %.2fs.\n", c, m, (double)(fim-inicio)/CLOCKS_PER_SEC);

            }
            else if(opcao==2) /** Insere Ultimo */
            {
                printf("\nInsira o Nome: ");
                scanf("%s", nome);
                printf("\nInsira o RG: ");
                scanf("%d", &rg);

                inicio=clock();

                novoNo=(CadastroE *)malloc(1*sizeof(CadastroE));

                strcpy(novoNo->nome,nome);
                novoNo->rg=rg;
                novoNo->anterior=ultimo;
                novoNo->proximo=NULL;
                ultimo->proximo=novoNo;
                ultimo=novoNo;

                i++;
                fim=clock();

                printf("\nAdicionado na ultima posicao, %d. C=0 e M=6. Tempo de Execucao: %.2fs.\n", i, (double)(fim-inicio)/CLOCKS_PER_SEC);

            }
            else if(opcao==3) /** Insere Posicao */
            {
                int n, j;
                c=0; m=0;

                printf("\nSelecione posicao para inserir, entre 1 e %d: ", i+1);
                scanf("%d", &n);

                while(n<0 || n>i+1)
                {
                    printf("\nPosicao Invalida. Selecione posicao para inserir, entre 1 e %d: ", i+1);
                    scanf("%d", &n);
                }

                printf("\nInsira o Nome: ");
                scanf("%s", nome);
                printf("\nInsira o RG: ");
                scanf("%d", &rg);

                inicio=clock();

                novoNo=(CadastroE *)malloc(1*sizeof(CadastroE));

                c++;
                if(n<=i/2)
                {
                    atual=primeiro;
                    m++;

                    for(j=1; j<n; j++)
                    {
                        c++;
                        atual=atual->proximo;
                        m++;
                    }
                }
                else
                {
                    atual=ultimo;
                    m++;

                    for(j=i; j>n; j--)
                    {
                        c++;
                        atual=atual->anterior;
                        m++;
                    }
                }

                strcpy(novoNo->nome,nome);
                novoNo->rg=rg;
                novoNo->proximo=NULL;
                m+=3;

                c++;
                if(atual==primeiro)
                {


                    c++;
                    if(primeiro!=NULL)
                    {
                        novoNo->proximo=primeiro;
                        primeiro->anterior=novoNo;
                        m+=2;
                    }
                    else
                    {
                        ultimo=novoNo;
                        m++;
                    }
                    primeiro=novoNo;
                    primeiro->anterior=NULL;

                }
                else if(atual==ultimo)
                {
                    c++;
                    strcpy(novoNo->nome,nome);
                    novoNo->rg=rg;
                    novoNo->anterior=ultimo;
                    novoNo->proximo=NULL;
                    ultimo->proximo=novoNo;
                    ultimo=novoNo;
                }
                else
                {
                    c++;
                    novoNo->proximo=atual;
                    novoNo->anterior=atual->anterior;
                    atual=atual->anterior;
                    atual->proximo=novoNo;
                    strcpy(novoNo->nome,nome);
                    novoNo->rg=rg;
                    m+=6;
                }

                i++;
                fim=clock();

                printf("\nAdicionado na posicao %d. C=%d e M=%d. Tempo de Execucao: %.2fs.\n", n, c, m, (double)(fim-inicio)/CLOCKS_PER_SEC);

            }
            else if(opcao==4) /** Retira Primeiro */
            {
                inicio=clock();

                if(primeiro==NULL)
                    printf("A lista esta vazia, impossivel retirar.");
                else
                {
                    atual=primeiro;
                    primeiro=primeiro->proximo;
                    primeiro->anterior=NULL;
                    free(atual);

                    i--;
                    fim=clock();

                    printf("\nRetirado da primeira posicao. C=1 e M=3. Tempo de Execucao: %.2fs.\n", (double)(fim-inicio)/CLOCKS_PER_SEC);
                }
            }
            else if(opcao==5) /** Retira Ultimo */
            {
                inicio=clock();

                if(ultimo==NULL)
                    printf("A lista esta vazia, impossivel retirar.");
                else
                {
                    atual=ultimo;
                    ultimo=ultimo->anterior;
                    ultimo->proximo=NULL;
                    free(atual);

                    i--;
                    fim=clock();

                    printf("\nRetirado da ultima posicao, %d. C=1 e M=3. Tempo de Execucao: %.2fs.\n", i+1, (double)(fim-inicio)/CLOCKS_PER_SEC);
                }
            }
            else if(opcao==6) /** Retira Posicao  */
            {
                c=0; m=0;

                c++;
                if(i==0)
                {
                    printf("\nA lista esta vazia.\n");
                }
                else
                {
                    int n, j;
                    CadastroE *auxP, *auxA;

                    printf("\nSelecione posicao para retirar, entre 1 e %d: ", i);
                    scanf("%d", &n);

                    while(n<1 || n>i)
                    {
                        printf("\nPosicao Invalida. Selecione posicao para retirar, entre 1 e %d: ", i);
                        scanf("%d", &n);
                    }

                    inicio=clock();

                    c++;
                    if(n<=i/2)
                    {
                        atual=primeiro;
                        m++;

                        for(j=1; j<n; j++)
                        {
                            c++;
                            atual=atual->proximo;
                            m++;
                        }
                    }
                    else
                    {
                        atual=ultimo;
                        m++;

                        for(j=i; j>n; j--)
                        {
                            c++;
                            atual=atual->anterior;
                            m++;
                        }
                    }
                    auxP=atual->proximo;
                    auxA=atual->anterior;
                    m+=2;

                    c++;
                    if(atual==primeiro)
                    {
                        primeiro=auxP;
                        primeiro->anterior=NULL;
                        m+=2;
                    }
                    else if(atual==ultimo)
                    {
                        c++;
                        ultimo=auxA;
                        ultimo->proximo=NULL;
                        m+=2;
                    }
                    else
                    {
                        c++;
                        auxA->proximo=atual->proximo;
                        auxP->anterior=atual->anterior;
                        m+=2;
                    }
                    i--;
                    fim=clock();

                    printf("\nRetirado da posicao %d. C=%d e M=%d. Tempo de Execucao: %.2fs.\n", n, c, m, (double)(fim-inicio)/CLOCKS_PER_SEC);
                }
            }
            else if(opcao==7) /** Procura RG */
            {
                c=0; m=0;
                int pesq, j=1, l=0;

                c++;
                if(primeiro==NULL)
                {
                    printf("\nA lista esta vazia.");
                }


                printf("\nEscolha o RG: ");
                scanf("%d", &pesq);

                inicio=clock();
                atual=primeiro;

                while(atual!=NULL)
                {
                    c+=2;
                    if(atual->rg==pesq)
                    {
                        printf("\nRG encontrado. Nome %s, posicao %d.\n", atual->nome, j);
                        l++;
                    }
                    atual=atual->proximo;
                    m++;
                    j++;
                }
                c++;
                if(l==0)
                    printf("\nRG nao encontrado. ");
                free(atual);

                fim=clock();

                printf("\nC=%d e M=%d. Tempo de Execucao: %.2fs.\n", c, m, (double)(fim-inicio)/CLOCKS_PER_SEC);

            }
            else if(opcao==8) /** Mostra Lista */
            {
                c=0; m=0;

                inicio=clock();

                c++;
                if(primeiro==NULL)
                {
                    printf("\nA lista esta vazia.");
                }
                else
                {
                    int j=1;

                    atual=primeiro;
                    m++;

                    while(atual!=NULL)
                    {
                        c++;
                        printf("\nLinha %d: %s, %d", j, atual->nome, atual->rg);
                        atual=atual->proximo;
                        m++;
                        j++;
                    }
                    free(atual);
                    fim=clock();

                    printf("\n\nFim da lista. C=%d e M=%d. Tempo de Execucao: %.2fs.\n", c, m, (double)(fim-inicio)/CLOCKS_PER_SEC);
                }

            }
            else if(opcao==9) /** Salva Lista */
            {
                c=0; m=0;

                printf("\nEscolha um nome para o arquivo ate 30 caracteres, contando com a extensao do mesmo: ");
                scanf("%s", &url);

                inicio=clock();
                arq = fopen(url, "w");
                c++;
                if(arq == NULL)
                {
                    fim=clock();
                    printf("\nErro, nao foi possivel salvar o arquivo.\n");
                }
                else
                {
                    atual=primeiro;
                    while(atual!=NULL)
                    {
                        c++;
                        fprintf(arq, "%s,%d", atual->nome, atual->rg);
                        atual=atual->proximo;
                    }
                    fclose(arq);
                    fim=clock();
                    printf("\nLista salva com sucesso. C=%d e M=%d. Tempo de Execucao: %.2fs.\n", c, m, (double)(fim-inicio)/CLOCKS_PER_SEC);
                }
            }
            else if(opcao==10) /** Recebe Lista */
            {
                c=0; m=0;

                printf("\nDigite o nome do arquivo, ate 30 caracteres, contando com a extensao do mesmo: ");
                scanf("%s", &url);

                inicio=clock();

                arq = fopen(url, "r");

                c++;
                if(arq == NULL)
                {
                    printf("\nErro, nao foi possivel abrir o arquivo.\n");
                    fclose(arq);
                }
                else
                {
                    while( (fscanf(arq,"%[^,],%d\n", nome, &rg))!=EOF )
                    {
                        c++;

                        novoNo=(CadastroE *)malloc(1*sizeof(CadastroE));

                        strcpy(novoNo->nome,nome);
                        novoNo->rg=rg;
                        novoNo->proximo=NULL;
                        m+=3;

                        c++;
                        if(primeiro==NULL)
                        {
                            primeiro=novoNo;
                            m++;
                        }
                        else
                        {
                            ultimo->proximo=novoNo;
                            novoNo->anterior=ultimo;
                            m+=2;
                        }

                        ultimo=novoNo;
                        m++;
                        i++;
                    }

                    fclose(arq);
                    fim=clock();

                    printf("\nLista carregada com sucesso. C=%d e M=%d. Tempo de Execucao: %.2fs.\n", c, m, (double)(fim-inicio)/CLOCKS_PER_SEC);
                }
            }
            else if(opcao<1 || opcao>11)
                printf("\nOpcao invalida.");
            printf("\n");
        }while(opcao!=11);

        return 1;
    }
}
